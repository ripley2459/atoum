<?php

	$BLOCK = $LINKS['THEMES'] . $THEME . '/includes/blocks/';
	
	include $BLOCK . 'accordion.php';
	include $BLOCK . 'button.php';
	include $BLOCK . 'div.php';
	include $BLOCK . 'form.php';
	include $BLOCK . 'horizontal_rule.php';
	include $BLOCK . 'image.php';
	include $BLOCK . 'line_break.php';
	include $BLOCK . 'link.php';
	include $BLOCK . 'list.php';
	include $BLOCK . 'paragraph.php';
	include $BLOCK . 'preformatted_text.php';
	include $BLOCK . 'section.php';
	include $BLOCK . 'table.php';
	include $BLOCK . 'title.php';