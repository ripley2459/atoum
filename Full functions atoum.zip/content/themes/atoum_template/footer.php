<div id="footer">
	My custom footer. Thème 2021.
	<a href="admin/admin.php">Admin</a>
</div>