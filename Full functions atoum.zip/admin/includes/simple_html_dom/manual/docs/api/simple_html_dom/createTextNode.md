# createTextNode

```php
createTextNode ( string $value ) : object
```

Creates a new text element.

Returns the element.