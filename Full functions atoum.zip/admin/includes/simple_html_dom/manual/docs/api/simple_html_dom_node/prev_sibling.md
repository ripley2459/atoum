# prev_sibling

```php
prev_sibling ( ) : object
```

Returns the previous sibling of the current node, or null if the current node has no previous sibling.